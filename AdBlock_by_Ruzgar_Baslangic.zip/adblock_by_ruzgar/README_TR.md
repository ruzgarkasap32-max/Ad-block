# AdBlock by Rüzgar — başlangıç projesi

Bu paket, Flutter ile Android ve iOS için hazırlanan ilk arayüz iskeletidir.

## Önemli
Bu sürüm henüz reklam engellemez. Ana ekrandaki düğme yalnızca arayüz durumunu değiştirir.
Gerçek engelleme için platforma özel ağ katmanı gerekir:
- Android: VPNService tabanlı yerel DNS filtreleme veya uygun bir Private DNS entegrasyonu.
- iOS: Network Extension / DNS Proxy ya da Safari Content Blocker. Gerekli Apple yetkileri ve imzalama ayarları gerekir.

Uygulamaların kendi akışlarına yerleştirdiği reklamların tamamını engellemek garanti edilemez.
Şifreli DNS/HTTPS trafiği, uygulama politikaları ve mağaza kuralları da dikkate alınmalıdır.

## Açma
1. Bilgisayara Flutter SDK ve Android Studio kur.
2. Bu klasörü aç.
3. Terminalde `flutter pub get` çalıştır.
4. Android cihaz veya emülatör bağla.
5. `flutter run` çalıştır.

iOS derlemesi için macOS ve Xcode gerekir. Windows üzerinde iOS uygulaması derlenemez.
