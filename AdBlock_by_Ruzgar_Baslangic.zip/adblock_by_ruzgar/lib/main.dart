import 'package:flutter/material.dart';

void main() => runApp(const AdBlockApp());

class AdBlockApp extends StatelessWidget {
  const AdBlockApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF081426);
    const blue = Color(0xFF35A7FF);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AdBlock by Rüzgar',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: blue,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool protectionEnabled = false;

  @override
  Widget build(BuildContext context) {
    final status = protectionEnabled ? 'Koruma açık' : 'Koruma kapalı';
    final statusColor = protectionEnabled
        ? const Color(0xFF35D07F)
        : const Color(0xFFFFB547);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ADBLOCK BY RÜZGAR',
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.1),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                const SizedBox(height: 24),
                Container(
                  width: 142,
                  height: 142,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF102B49),
                    border: Border.all(color: const Color(0xFF35A7FF), width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x5535A7FF),
                        blurRadius: 28,
                        spreadRadius: 2,
                      )
                    ],
                  ),
                  child: const Icon(Icons.shield_outlined,
                      size: 76, color: Color(0xFF35A7FF)),
                ),
                const SizedBox(height: 28),
                Text(status,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    )),
                const SizedBox(height: 10),
                const Text(
                  'Cihazındaki reklam korumasını buradan yönet.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, fontSize: 15),
                ),
                const SizedBox(height: 30),
                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: FilledButton.icon(
                    onPressed: () => setState(
                        () => protectionEnabled = !protectionEnabled),
                    icon: Icon(protectionEnabled
                        ? Icons.pause_circle_outline
                        : Icons.play_circle_outline),
                    label: Text(
                      protectionEnabled ? 'KORUMAYI DURDUR' : 'KORUMAYI ETKİNLEŞTİR',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, letterSpacing: .4),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                _InfoTile(
                  icon: Icons.public,
                  title: 'İnternet reklamları',
                  subtitle: 'DNS filtreleme motoru sonraki aşamada eklenecek.',
                ),
                _InfoTile(
                  icon: Icons.privacy_tip_outlined,
                  title: 'Gizlilik koruması',
                  subtitle: 'Bilinen takip alan adları için filtre listeleri planlandı.',
                ),
                _InfoTile(
                  icon: Icons.phone_android,
                  title: 'Android ve iOS',
                  subtitle: 'Platformlara özel ağ izinleri ve entegrasyon gerekiyor.',
                ),
                const SizedBox(height: 18),
                const Text(
                  'Başlangıç arayüzü • Henüz gerçek reklam engellemesi yapmaz',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF10233B),
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF35A7FF), size: 28),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
      ),
    );
  }
}
